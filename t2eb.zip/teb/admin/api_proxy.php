<?php
header('Content-Type: application/json; charset=utf-8');

// TC parametresi var mı kontrol et
if (!isset($_GET['tc'])) {
    http_response_code(400);
    echo json_encode(["error" => "tc parametresi eksik"]);
    exit;
}

$tc = preg_replace('/[^0-9]/', '', $_GET['tc']); // sadece rakam

// Ondex API URL
$url = "http://api.ondex.uk/ondexapi/tcprosorgu.php?tc={$tc}";

// API isteği
$response = @file_get_contents($url);

// API’den cevap gelmezse hata döndür
if ($response === false) {
    http_response_code(500);
    echo json_encode(["error" => "API erişilemedi"]);
    exit;
}

// Gelen yanıtı direkt kullanıcıya döndür
echo $response;
