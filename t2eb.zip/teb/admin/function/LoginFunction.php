<?php
include 'MainFunction.php';
$stmt = $pdo->prepare('SELECT * FROM admin WHERE kullanici_adi = ?');
$stmt->execute([ $_POST['usernameS'] ]);
$account = $stmt->fetch(PDO::FETCH_ASSOC);
if ($account) {
	if (password_verify($_POST['passwordS'], $account['sifre'])) {
		session_regenerate_id();
		$_SESSION['giris_yapildi'] = TRUE;
		$_SESSION['name'] = $account['kullanici_adi'];
		$_SESSION['id'] = $account['id'];
		if (isset($_POST['beni_hatirla'])) {
			$cookiehash = !empty($account['beni_hatirla']) ? $account['beni_hatirla'] : password_hash($account['id'] . $account['kullanici_adi'] . 'phishmastersecretkey', PASSWORD_DEFAULT);
			$days = 30;
			setcookie('beni_hatirla', $cookiehash, (int)(time()+60*60*24*$days));
			$stmt = $pdo->prepare('UPDATE admin SET beni_hatirla = ? WHERE kullanici_adi = ?');
			$stmt->execute([ $cookiehash, $_POST['usernameS'] ]);
		}
		$date = date('d.m.Y H:i:s');
		$stmt = $pdo->prepare('UPDATE admin SET son_gorulme = ?, ip_adresi = ? WHERE kullanici_adi = ?');
		$stmt->execute([ $date, $ip, $_POST['usernameS'] ]);
		echo 'Başarılı';
	} else {
		echo 'Lütfen geçerli bir şifre giriniz.';
	}
} else {
	echo 'Lütfen geçerli bir kullanıcı adı giriniz.';
}
?>