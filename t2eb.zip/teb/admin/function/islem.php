<?php
include_once('../../config.php');
include '../Data/Server/GrabIP.php';

function tum_bosluklari_temizle($metin) {
    $metin = str_replace("/s+/", "", $metin);
    $metin = str_replace(" ", "", $metin);
    $metin = str_replace(" ", "", $metin);
    $metin = str_replace(" ", "", $metin);
    $metin = str_replace("/s/g", "", $metin);
    $metin = str_replace("/s+/g", "", $metin);
    $metin = trim($metin);
    return $metin;
  }

$islem = $_POST['islem'];
$ip = $_POST['ip'];

if ($islem and $ip) {
    if($islem == "sil") {
        $pdo->query("DELETE FROM logs WHERE ip='$ip'");
        $pdo->query("DELETE FROM logs_visitor WHERE ip='$ip'");
        exit;
    } else if($islem == "yasakla") {
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "http://ip-api.com/json/$ip",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        ]);
        $response = curl_exec($curl);
        $err = curl_error($curl);
    
        curl_close($curl);
    
        if ($err) {
            echo "cURL Error #:" . $err;
        } else {
            $json = json_decode($response);
            $il = $json->regionName;
            $ilce = $json->city;
        
            if($il == null) {
            $il = "Bulunamadı";
            }
            if($ilce == null) {
            $ilce = "Bulunamadı";
            }
        }
    
        $tarih = date('d.m.Y H:i');
        
        $logsorgu = $pdo->query("SELECT * FROM logs WHERE ip = '{$ip}'")->fetch(PDO::FETCH_ASSOC);
    
        $cihaz = $logsorgu['device'];
        $tarayici = $logsorgu['browser'];
        
        $pdo->query("INSERT INTO bans SET ip=('$ip'),konum=('$il' ', $ilce'),cihaz=('$cihaz'),tarayici=('$tarayici'),tarih=('$tarih')");
    
        $pdo->query("DELETE FROM logs WHERE ip='$ip'");
        $pdo->query("DELETE FROM logs_visitor WHERE ip='$ip'");
        exit;
    } else {
        $pdo->query("INSERT INTO $islem ($islem) VALUES ('$ip')");
        exit;
    }
}
?>