<?php
include_once('../../config.php');
include '../Data/Server/GrabIP.php';
session_start();

function giris_dogrulama($pdo) {
    if (isset($_COOKIE['beni_hatirla']) && !empty($_COOKIE['beni_hatirla']) && !isset($_SESSION['giris_yapildi'])) {
    	$stmt = $pdo->prepare('SELECT * FROM admin WHERE beni_hatirla = ?');
    	$stmt->execute([ $_COOKIE['beni_hatirla'] ]);
    	$account = $stmt->fetch(PDO::FETCH_ASSOC);
    	if ($account) {
    	session_regenerate_id();
    	$_SESSION['giris_yapildi'] = TRUE;
    	$_SESSION['kullanici'] = $account['kullanici_adi'];
    	$_SESSION['id'] = $account['id'];
			$date = date('d.m.Y H:i:s');
			$stmt = $pdo->prepare('UPDATE admin SET son_gorulme = ? WHERE ip_adresi = ?');
			$stmt->execute([ $date, $ip ]);
    	} else {
    		header('Location: /admin');
    		exit;
    	}
    } else if(!isset($_SESSION['giris_yapildi'])) {
    	header('Location: /admin');
    	exit;
    }
}

//Tablo Sayı
$logSQL = $pdo->query("SELECT COUNT(*) FROM logs");
$log_sayisi = $logSQL->fetchColumn();

$banSQL = $pdo->query("SELECT COUNT(*) FROM bans");
$ban_sayisi = $banSQL->fetchColumn();

//Günün Mesajı
if ( date('G') >= 5 && date('G') <= 11 ) { $mesaj = "Günaydın"; } else if ( date('G') >= 12 && date('G') <= 18 ) { $mesaj = "İyi Günler"; } else if ( date('G') >= 19 || date('G') <= 4 ) { $mesaj = "İyi Geceler"; }

//Zamanı Formatla
function ZamaniFormatla($time) { $time = strtotime($time); $timeDifference = time() - $time; $second = $timeDifference; $minute = round($timeDifference/60); $hour = round($timeDifference/3600); $day = round($timeDifference/86400); $week = round($timeDifference/604800); $month = round($timeDifference/2419200); $year = round($timeDifference/29030400); if ($second < 60) { if ($second === 0) {   return 'Az önce'; } else {   return $second .' saniye önce'; } } else if ($minute < 60) {   return $minute .' dakika önce'; } else if ($hour < 24) {   return $hour.' saat önce'; } else if ($day < 7) {   return $day .' gün önce'; } else if ($week < 4) {   return $week.' hafta önce'; } else if ($month < 12) {   return $month .' ay önce'; } else {   return $year.' yıl önce'; } }


?>